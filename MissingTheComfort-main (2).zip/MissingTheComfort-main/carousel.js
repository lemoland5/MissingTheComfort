const slidesContainer = document.getElementById("slides-container");
const slide = document.querySelector(".slide");
const prevButton = document.getElementById("slide-arrow-prev");
const nextButton = document.getElementById("slide-arrow-next");
const spacer = document.getElementById("carouselSpacer")

let carouselWidth = slidesContainer.scrollWidth

let carouselY =  slidesContainer.getBoundingClientRect().top + window.scrollY
let carouselBottom = carouselY + carouselWidth
let carouselHeight = carouselBottom - carouselY
spacer.style.height = carouselHeight + "px"

window.addEventListener("scroll", ()=>{

  console.log(window.scrollY)
  console.log(carouselY)
  
  if(window.scrollY >= carouselY && window.scrollY <= carouselBottom){
    slidesContainer.style.position = "sticky"
    slidesContainer.scrollLeft = window.scrollY - carouselY
  }
  if(window.scrollY > carouselBottom){
    console.log("passed")
    slidesContainer.style.position = "relative"
  }

})

nextButton.addEventListener("click", () => {
  const slideWidth = slide.clientWidth;
  slidesContainer.scrollLeft += slideWidth;
});

prevButton.addEventListener("click", () => {
  const slideWidth = slide.clientWidth;
  slidesContainer.scrollLeft -= slideWidth;
});
